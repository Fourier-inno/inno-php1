<!DOCTYPE html>
    <html lang="en">

    <head>
      <meta charset="UTF-8">
       <title>Welcome to the home page</title>
   </head>
   </html>